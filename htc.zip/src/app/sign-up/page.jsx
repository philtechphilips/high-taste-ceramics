"use client";

import { useState, useEffect } from "react";
import { signUp } from "../../services/auth.service";
import { Toaster, toast } from 'react-hot-toast';
import MainLayout from "../../components/MainLayout";
import Link from "next/link";
import { useRouter } from "next/navigation";
import withAuth from "../../components/withAuth";
import useAuthStore from "../../store/authStore";

const SignUp = () => {
  const user = useAuthStore((state) => state.user);
  const router = useRouter();
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated && user) {
      router.replace("/");
    }
  }, [user, router, hydrated]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await signUp(firstname, lastname, email, password);
      toast.success("Account created! Please sign in.");
      router.push("/sign-in");
    } catch (err) {
      toast.error(err?.response?.data?.message || "Sign up failed");
    } finally {
      setLoading(false);
    }
  };

  if (!hydrated) return null;
  if (user) return null;

  return (
    <MainLayout>
      <section className="w-full md:px-10 px-5 bg-[#F0F0F0] pt-60 pb-20">
        <div className="max-w-7xl mx-auto">
          <h1 className="md:text-5xl text-3xl !font-[300] text-[#242222] font-[Publicko] text-center leading-18">
            Create an Account
          </h1>
          <div className="w-full flex items-center justify-center py-10">
            <form className="flex flex-col gap-8 bg-[#F8F8F8] p-8 md:p-12 w-[650px]" onSubmit={handleSubmit}>
              <h2 className="text-xl md:text-3xl font-[Publicko] text-[#242222]">
                New Customer? Create an Account
              </h2>
              <div className="border-b border-[#242222]/20 my-2"></div>
              <p className="text-[#242222] -mt-6">
                Sign up to check order status, or review past orders.
              </p>
              <div className="relative">
                <input
                  type="text"
                  id="firstname"
                  value={firstname}
                  onChange={e => setFirstname(e.target.value)}
                  className="w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]"
                  placeholder="Firstname"
                />
                <label
                  htmlFor="firstname"
                  className="absolute left-4 top-2 text-sm text-[#777]"
                >
                  Firstname
                </label>
              </div>
              <div className="relative">
                <input
                  type="text"
                  id="lastname"
                  value={lastname}
                  onChange={e => setLastname(e.target.value)}
                  className="w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]"
                  placeholder="Lastname"
                />
                <label
                  htmlFor="lastname"
                  className="absolute left-4 top-2 text-sm text-[#777]"
                >
                  Lastname
                </label>
              </div>
              <div className="relative">
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]"
                  placeholder="Email"
                />
                <label
                  htmlFor="email"
                  className="absolute left-4 top-2 text-sm text-[#777]"
                >
                  Email
                </label>
              </div>
              <div className="relative">
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]"
                  placeholder="Password"
                />
                <label
                  htmlFor="password"
                  className="absolute left-4 top-2 text-sm text-[#777]"
                >
                  Password
                </label>
              </div>
              <button
                type="submit"
                className="bg-[#242222] text-white py-3 px-6 rounded-xl hover:bg-[#3a3838] transition-all duration-200 text-base font-medium shadow-md flex items-center justify-center gap-2"
                disabled={loading}
              >
                {loading && (
                  <span className="inline-block w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                )}
                {loading ? "Signing Up..." : "Sign Up"}
              </button>
              <p className="text-center">
                Already have an account?{" "}
                <Link href="/sign-in" className="underline">
                  Sign in.
                </Link>
              </p>
            </form>
          </div>
        </div>
        <Toaster position="top-right" />
      </section>
    </MainLayout>
  );
};

export default withAuth(SignUp, { requireAuth: false });
