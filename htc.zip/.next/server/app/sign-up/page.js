(()=>{var e={};e.id=884,e.ids=[884],e.modules={2629:(e,t,r)=>{"use strict";r.d(t,{H:()=>i,J:()=>a});var s=r(16261);let a=async(e,t)=>(await s.A.post("/auth/login",{email:e,password:t})).data,i=async(e,t,r,a)=>(await s.A.post("/auth/register",{firstName:e,lastName:t,email:r,password:a})).data},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12412:e=>{"use strict";e.exports=require("assert")},16261:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let s=r(51060).A.create({baseURL:"https://api.hightasteceramics.com/api",withCredentials:!1});s.interceptors.response.use(e=>e,e=>(e.response&&e.response.status,Promise.reject(e)));let a=s},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},37590:(e,t,r)=>{"use strict";r.d(t,{l$:()=>ec,Ay:()=>ed,oR:()=>F});var s,a=r(43210);let i={data:""},o=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||i,n=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,l=/\/\*[^]*?\*\/|  +/g,c=/\n+/g,d=(e,t)=>{let r="",s="",a="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?r=i+" "+o+";":s+="f"==i[1]?d(o,i):i+"{"+d(o,"k"==i[1]?"":t)+"}":"object"==typeof o?s+=d(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),a+=d.p?d.p(i,o):i+":"+o+";")}return r+(t&&a?t+"{"+a+"}":a)+s},u={},p=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+p(e[r]);return t}return e},m=(e,t,r,s,a)=>{let i=p(e),o=u[i]||(u[i]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(i));if(!u[o]){let t=i!==e?e:(e=>{let t,r,s=[{}];for(;t=n.exec(e.replace(l,""));)t[4]?s.shift():t[3]?(r=t[3].replace(c," ").trim(),s.unshift(s[0][r]=s[0][r]||{})):s[0][t[1]]=t[2].replace(c," ").trim();return s[0]})(e);u[o]=d(a?{["@keyframes "+o]:t}:t,r?"":"."+o)}let m=r&&u.g?u.g:null;return r&&(u.g=u[o]),((e,t,r,s)=>{s?t.data=t.data.replace(s,e):-1===t.data.indexOf(e)&&(t.data=r?e+t.data:t.data+e)})(u[o],t,s,m),o},f=(e,t,r)=>e.reduce((e,s,a)=>{let i=t[a];if(i&&i.call){let e=i(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+s+(null==i?"":i)},"");function h(e){let t=this||{},r=e.call?e(t.p):e;return m(r.unshift?r.raw?f(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,o(t.target),t.g,t.o,t.k)}h.bind({g:1});let x,g,b,y=h.bind({k:1});function v(e,t){let r=this||{};return function(){let s=arguments;function a(i,o){let n=Object.assign({},i),l=n.className||a.className;r.p=Object.assign({theme:g&&g()},n),r.o=/ *go\d+/.test(l),n.className=h.apply(r,s)+(l?" "+l:""),t&&(n.ref=o);let c=e;return e[0]&&(c=n.as||e,delete n.as),b&&c[0]&&b(n),x(c,n)}return t?t(a):a}}var w=e=>"function"==typeof e,j=(e,t)=>w(e)?e(t):e,N=(()=>{let e=0;return()=>(++e).toString()})(),P=(()=>{let e;return()=>e})(),E=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return E(e,{type:+!!e.toasts.find(e=>e.id===r.id),toast:r});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let a=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+a}))}}},k=[],C={toasts:[],pausedAt:void 0},A=e=>{C=E(C,e),k.forEach(e=>{e(C)})},q={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},$=(e={})=>{let[t,r]=(0,a.useState)(C),s=(0,a.useRef)(C);(0,a.useEffect)(()=>(s.current!==C&&r(C),k.push(r),()=>{let e=k.indexOf(r);e>-1&&k.splice(e,1)}),[]);let i=t.toasts.map(t=>{var r,s,a;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(s=e[t.type])?void 0:s.duration)||(null==e?void 0:e.duration)||q[t.type],style:{...e.style,...null==(a=e[t.type])?void 0:a.style,...t.style}}});return{...t,toasts:i}},D=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||N()}),_=e=>(t,r)=>{let s=D(t,e,r);return A({type:2,toast:s}),s.id},F=(e,t)=>_("blank")(e,t);F.error=_("error"),F.success=_("success"),F.loading=_("loading"),F.custom=_("custom"),F.dismiss=e=>{A({type:3,toastId:e})},F.remove=e=>A({type:4,toastId:e}),F.promise=(e,t,r)=>{let s=F.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let a=t.success?j(t.success,e):void 0;return a?F.success(a,{id:s,...r,...null==r?void 0:r.success}):F.dismiss(s),e}).catch(e=>{let a=t.error?j(t.error,e):void 0;a?F.error(a,{id:s,...r,...null==r?void 0:r.error}):F.dismiss(s)}),e};var S=(e,t)=>{A({type:1,toast:{id:e,height:t}})},I=()=>{A({type:5,time:Date.now()})},O=new Map,z=1e3,R=(e,t=z)=>{if(O.has(e))return;let r=setTimeout(()=>{O.delete(e),A({type:4,toastId:e})},t);O.set(e,r)},U=e=>{let{toasts:t,pausedAt:r}=$(e);(0,a.useEffect)(()=>{if(r)return;let e=Date.now(),s=t.map(t=>{if(t.duration===1/0)return;let r=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(r<0){t.visible&&F.dismiss(t.id);return}return setTimeout(()=>F.dismiss(t.id),r)});return()=>{s.forEach(e=>e&&clearTimeout(e))}},[t,r]);let s=(0,a.useCallback)(()=>{r&&A({type:6,time:Date.now()})},[r]),i=(0,a.useCallback)((e,r)=>{let{reverseOrder:s=!1,gutter:a=8,defaultPosition:i}=r||{},o=t.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...s?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+a,0)},[t]);return(0,a.useEffect)(()=>{t.forEach(e=>{if(e.dismissed)R(e.id,e.removeDelay);else{let t=O.get(e.id);t&&(clearTimeout(t),O.delete(e.id))}})},[t]),{toasts:t,handlers:{updateHeight:S,startPause:I,endPause:s,calculateOffset:i}}},M=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,H=y`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,L=y`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,T=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${M} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${H} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${L} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,G=y`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,B=v("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${G} 1s linear infinite;
`,J=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,K=y`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,X=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${J} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${K} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,Y=v("div")`
  position: absolute;
`,Z=v("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,Q=y`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,V=v("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${Q} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,W=({toast:e})=>{let{icon:t,type:r,iconTheme:s}=e;return void 0!==t?"string"==typeof t?a.createElement(V,null,t):t:"blank"===r?null:a.createElement(Z,null,a.createElement(B,{...s}),"loading"!==r&&a.createElement(Y,null,"error"===r?a.createElement(T,{...s}):a.createElement(X,{...s})))},ee=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,et=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,er=v("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,es=v("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ea=(e,t)=>{let r=e.includes("top")?1:-1,[s,a]=P()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ee(r),et(r)];return{animation:t?`${y(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${y(a)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},ei=a.memo(({toast:e,position:t,style:r,children:s})=>{let i=e.height?ea(e.position||t||"top-center",e.visible):{opacity:0},o=a.createElement(W,{toast:e}),n=a.createElement(es,{...e.ariaProps},j(e.message,e));return a.createElement(er,{className:e.className,style:{...i,...r,...e.style}},"function"==typeof s?s({icon:o,message:n}):a.createElement(a.Fragment,null,o,n))});s=a.createElement,d.p=void 0,x=s,g=void 0,b=void 0;var eo=({id:e,className:t,style:r,onHeightUpdate:s,children:i})=>{let o=a.useCallback(t=>{if(t){let r=()=>{s(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,s]);return a.createElement("div",{ref:o,className:t,style:r},i)},en=(e,t)=>{let r=e.includes("top"),s=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:P()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...r?{top:0}:{bottom:0},...s}},el=h`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ec=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:s,children:i,containerStyle:o,containerClassName:n})=>{let{toasts:l,handlers:c}=U(r);return a.createElement("div",{id:"_rht_toaster",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...o},className:n,onMouseEnter:c.startPause,onMouseLeave:c.endPause},l.map(r=>{let o=r.position||t,n=en(o,c.calculateOffset(r,{reverseOrder:e,gutter:s,defaultPosition:t}));return a.createElement(eo,{id:r.id,key:r.id,onHeightUpdate:c.updateHeight,className:r.visible?el:"",style:n},"custom"===r.type?j(r.message,r):i?i(r):a.createElement(ei,{toast:r,position:o}))}))},ed=F},39502:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>o.a,__next_app__:()=>u,pages:()=>d,routeModule:()=>p,tree:()=>c});var s=r(65239),a=r(48088),i=r(88170),o=r.n(i),n=r(30893),l={};for(let e in n)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>n[e]);r.d(t,l);let c={children:["",{children:["sign-up",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,47076)),"C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\sign-up\\page.jsx"]}]},{metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(r.bind(r,75535)),"C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\layout.js"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,57398,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,d=["C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\sign-up\\page.jsx"],u={require:r,loadChunk:()=>Promise.resolve()},p=new s.AppPageRouteModule({definition:{kind:a.RouteKind.APP_PAGE,page:"/sign-up/page",pathname:"/sign-up",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},41927:(e,t,r)=>{Promise.resolve().then(r.bind(r,93178))},47076:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>s});let s=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\Pelumi Isola\\\\Desktop\\\\high-taste-ceramics\\\\src\\\\app\\\\sign-up\\\\page.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\sign-up\\page.jsx","default")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},82095:(e,t,r)=>{Promise.resolve().then(r.bind(r,47076))},83997:e=>{"use strict";e.exports=require("tty")},91368:(e,t,r)=>{"use strict";r.d(t,{A:()=>o});var s=r(60687);r(43210);var a=r(16189),i=r(72106);function o(e,{requireAuth:t=!1,redirectTo:r="/sign-in"}={}){return function(r){(0,a.useRouter)();let o=(0,i.A)(e=>e.user);return t&&!o||!t&&o?null:(0,s.jsx)(e,{...r})}}},93178:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>m});var s=r(60687),a=r(43210),i=r(2629),o=r(37590),n=r(39952),l=r(85814),c=r.n(l),d=r(16189),u=r(91368),p=r(72106);let m=(0,u.A)(()=>{let e=(0,p.A)(e=>e.user),t=(0,d.useRouter)(),[r,l]=(0,a.useState)(""),[u,m]=(0,a.useState)(""),[f,h]=(0,a.useState)(""),[x,g]=(0,a.useState)(""),[b,y]=(0,a.useState)(!1),[v,w]=(0,a.useState)(!1);(0,a.useEffect)(()=>{w(!0)},[]),(0,a.useEffect)(()=>{v&&e&&t.replace("/")},[e,t,v]);let j=async e=>{e.preventDefault(),y(!0);try{await (0,i.H)(r,u,f,x),o.oR.success("Account created! Please sign in."),t.push("/sign-in")}catch(e){o.oR.error(e?.response?.data?.message||"Sign up failed")}finally{y(!1)}};return!v||e?null:(0,s.jsx)(n.A,{children:(0,s.jsxs)("section",{className:"w-full md:px-10 px-5 bg-[#F0F0F0] pt-60 pb-20",children:[(0,s.jsxs)("div",{className:"max-w-7xl mx-auto",children:[(0,s.jsx)("h1",{className:"md:text-5xl text-3xl !font-[300] text-[#242222] font-[Publicko] text-center leading-18",children:"Create an Account"}),(0,s.jsx)("div",{className:"w-full flex items-center justify-center py-10",children:(0,s.jsxs)("form",{className:"flex flex-col gap-8 bg-[#F8F8F8] p-8 md:p-12 w-[650px]",onSubmit:j,children:[(0,s.jsx)("h2",{className:"text-xl md:text-3xl font-[Publicko] text-[#242222]",children:"New Customer? Create an Account"}),(0,s.jsx)("div",{className:"border-b border-[#242222]/20 my-2"}),(0,s.jsx)("p",{className:"text-[#242222] -mt-6",children:"Sign up to check order status, or review past orders."}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"text",id:"firstname",value:r,onChange:e=>l(e.target.value),className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Firstname"}),(0,s.jsx)("label",{htmlFor:"firstname",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Firstname"})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"text",id:"lastname",value:u,onChange:e=>m(e.target.value),className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Lastname"}),(0,s.jsx)("label",{htmlFor:"lastname",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Lastname"})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"email",id:"email",value:f,onChange:e=>h(e.target.value),className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Email"}),(0,s.jsx)("label",{htmlFor:"email",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Email"})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"password",id:"password",value:x,onChange:e=>g(e.target.value),className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Password"}),(0,s.jsx)("label",{htmlFor:"password",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Password"})]}),(0,s.jsxs)("button",{type:"submit",className:"bg-[#242222] text-white py-3 px-6 rounded-xl hover:bg-[#3a3838] transition-all duration-200 text-base font-medium shadow-md flex items-center justify-center gap-2",disabled:b,children:[b&&(0,s.jsx)("span",{className:"inline-block w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"}),b?"Signing Up...":"Sign Up"]}),(0,s.jsxs)("p",{className:"text-center",children:["Already have an account?"," ",(0,s.jsx)(c(),{href:"/sign-in",className:"underline",children:"Sign in."})]})]})})]}),(0,s.jsx)(o.l$,{position:"top-right"})]})})},{requireAuth:!1})},94735:e=>{"use strict";e.exports=require("events")}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[447,825,224,151,60,643],()=>r(39502));module.exports=s})();