(()=>{var e={};e.id=279,e.ids=[279],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6098:(e,t,r)=>{Promise.resolve().then(r.bind(r,8347))},8347:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>m});var s=r(60687),a=r(85814),i=r.n(a),o=r(43210),l=r(37590),n=r(39952),c=r(72106),d=r(5082),u=r(91368),p=r(14606);let m=(0,u.A)(()=>{let e=(0,c.A)(e=>e.user),{cart:t}=(0,d.A)(),[r,a]=(0,o.useState)({firstName:e?.firstName||"",lastName:e?.lastName||"",email:e?.email||"",phoneNumber:e?.phoneNumber||"",address:e?.address||"",street:e?.street||"",apartment:e?.apartment||"",city:e?.city||"",state:e?.state||""}),[u,m]=(0,o.useState)(!1),x=e=>{a({...r,[e.target.name]:e.target.value})},h=async s=>{if(s.preventDefault(),["firstName","lastName","email","phoneNumber","address","street","city","state"].find(e=>!r[e]?.trim()))return void l.Ay.error("Please fill in all required fields.");m(!0);try{let s={userId:e?._id||e?.id,...r,cart:t.map(e=>({productId:e.id,quantity:e.count||1}))};await (0,p.Pt)(s,e?.token),l.Ay.success("Order submitted successfully!")}catch(e){l.Ay.error("Failed to submit order. Please try again.")}finally{m(!1)}};return(0,s.jsxs)(n.A,{children:[(0,s.jsx)("section",{className:"w-full py-40 pt-60 flex flex-col items-center justify-center bg-[#EFEBE2]",children:(0,s.jsxs)("div",{className:"md:w-160 w-full flex flex-col gap-8 items-center",children:[(0,s.jsx)("h1",{className:"md:text-[140px] text-4xl !font-[300] text-[#242222] font-[Publicko] text-center leading-18",children:"Checkout"}),(0,s.jsx)("p",{className:"text-center text-[#242222] font-light",children:"Please review your order and proceed to checkout."})]})}),(0,s.jsxs)("section",{className:"w-full flex flex-col md:flex-row gap-10  md:px-10 px-5 bg-[#f0f0f0] pt-20 pb-20",children:[(0,s.jsxs)("div",{className:"md:w-1/2 w-full bg-[#F0F0F0] pb-5",children:[(0,s.jsxs)("div",{className:"w-full",children:[(0,s.jsx)("h1",{className:"md:text-3xl text-xl !font-[300] text-[#242222] font-[Publicko] leading-18",children:"Customer Information"}),(0,s.jsx)("div",{className:"w-full flex items-center justify-center py-10",children:(0,s.jsxs)("form",{className:"flex flex-col gap-8  w-full",onSubmit:h,children:[(0,s.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"text",id:"firstName",name:"firstName",required:!0,value:r.firstName,onChange:x,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"First Name"}),(0,s.jsx)("label",{htmlFor:"firstName",className:"absolute left-4 top-2 text-sm text-[#777]",children:"First Name"})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"text",id:"lastName",name:"lastName",required:!0,value:r.lastName,onChange:x,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Last Name"}),(0,s.jsx)("label",{htmlFor:"lastName",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Last Name"})]})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"email",id:"email",name:"email",required:!0,value:r.email,onChange:x,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Email"}),(0,s.jsx)("label",{htmlFor:"email",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Email"})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"tel",id:"phoneNumber",name:"phoneNumber",required:!0,value:r.phoneNumber,onChange:x,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Phone Number"}),(0,s.jsx)("label",{htmlFor:"phoneNumber",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Phone Number"})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"text",id:"address",name:"address",required:!0,value:r.address,onChange:x,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Address"}),(0,s.jsx)("label",{htmlFor:"address",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Address"})]}),(0,s.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"text",id:"street",name:"street",value:r.street,onChange:x,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Street"}),(0,s.jsx)("label",{htmlFor:"street",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Street"})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"text",id:"apartment",name:"apartment",value:r.apartment,onChange:x,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Apartment (optional)"}),(0,s.jsx)("label",{htmlFor:"apartment",className:"absolute left-4 top-2 text-sm text-[#777]",children:"Apartment"})]})]}),(0,s.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"text",id:"city",name:"city",required:!0,value:r.city,onChange:x,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"City"}),(0,s.jsx)("label",{htmlFor:"city",className:"absolute left-4 top-2 text-sm text-[#777]",children:"City"})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{type:"text",id:"state",name:"state",required:!0,value:r.state,onChange:x,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"State"}),(0,s.jsx)("label",{htmlFor:"state",className:"absolute left-4 top-2 text-sm text-[#777]",children:"State"})]})]}),(0,s.jsxs)("button",{type:"submit",className:"bg-[#242222] text-white py-3 px-6 rounded-xl hover:bg-[#3a3838] transition-all duration-200 text-base font-medium shadow-md flex items-center justify-center gap-2",disabled:u,children:[u&&(0,s.jsxs)("svg",{className:"animate-spin h-5 w-5 text-white",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",children:[(0,s.jsx)("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4"}),(0,s.jsx)("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"})]}),u?"Submitting...":"Proceed to Submit Your Quote"]})]})})]}),(0,s.jsx)("div",{className:"max-w-1/2 mx-auto"}),(0,s.jsx)(l.l$,{position:"top-right"})]}),(0,s.jsxs)("div",{className:"md:w-1/2 w-full",children:[(0,s.jsx)("h1",{className:"md:text-3xl text-xl !font-[300] text-[#242222] font-[Publicko] leading-18",children:"Your Order Summary"}),(0,s.jsx)("p",{className:"text-lg text-[#242222] mb-4",children:"Thank you for choosing our products. Please confirm your order details below."}),(0,s.jsxs)("div",{className:"bg-gray-100 p-6 rounded-lg",children:[(0,s.jsx)("p",{className:"text-lg font-medium text-[#242222] mb-4",children:"Order Summary"}),t.length>0?(0,s.jsxs)("div",{className:"flex flex-col gap-6",children:[(0,s.jsxs)("div",{className:"hidden md:grid grid-cols-12 gap-4 pb-2 border-b border-[#242222]/10",children:[(0,s.jsx)("div",{className:"col-span-6 font-medium text-[#242222]",children:"Product"}),(0,s.jsx)("div",{className:"col-span-3 font-medium text-[#242222] text-center",children:"Quantity"}),(0,s.jsx)("div",{className:"col-span-3 font-medium text-[#242222] text-right",children:"Category"})]}),t.map(e=>(0,s.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-12 gap-4 py-4 border-b border-[#242222]/10",children:[(0,s.jsxs)("div",{className:"col-span-6 flex items-center gap-4",children:[(0,s.jsx)("div",{className:"relative w-16 h-16 overflow-hidden rounded-md bg-white border border-[#eee]",children:(0,s.jsx)("img",{src:e?.image,alt:e?.name,className:"object-cover w-full h-full"})}),(0,s.jsx)("div",{children:(0,s.jsx)("h3",{className:"text-base font-medium text-[#242222]",children:e?.name})})]}),(0,s.jsx)("div",{className:"col-span-3 flex items-center justify-center",children:(0,s.jsx)("span",{className:"px-3 py-1 bg-white rounded-full border border-[#ccc] min-w-[40px] text-center",children:e.count||1})}),(0,s.jsx)("div",{className:"col-span-3 flex items-center justify-end",children:(0,s.jsx)("span",{className:"text-sm text-[#5a5a5a]",children:e?.category?.name})})]},e?.id))]}):(0,s.jsx)("div",{className:"text-center py-6 text-[#5a5a5a]",children:"No items in cart."})]}),(0,s.jsx)("div",{className:"mt-8 flex justify-end",children:(0,s.jsx)(i(),{href:"/cart",className:"px-6 py-3 bg-[#242222] text-white rounded-full hover:bg-black transition-colors duration-300",children:"Go to Cart"})})]})]})]})},{requireAuth:!0})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12412:e=>{"use strict";e.exports=require("assert")},14606:(e,t,r)=>{"use strict";r.d(t,{Kl:()=>a,Pt:()=>n,cw:()=>i,jy:()=>o,qR:()=>l});var s=r(16261);let a=async e=>(await s.A.get("/product/categories")).data,i=async()=>(await s.A.get("/product/featured")).data,o=async e=>(await s.A.get(`/product/category/${e}`)).data,l=async e=>(await s.A.get(`/product/${e}`)).data,n=async(e,t)=>(console.log("Checkout data:",e),(await s.A.post("/cart/checkout",{...e},{headers:{Authorization:`Bearer ${t}`}})).data)},16261:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let s=r(51060).A.create({baseURL:"https://api.hightasteceramics.com/api",withCredentials:!1});s.interceptors.response.use(e=>e,e=>(e.response&&e.response.status,Promise.reject(e)));let a=s},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},37590:(e,t,r)=>{"use strict";r.d(t,{l$:()=>ec,Ay:()=>ed,oR:()=>D});var s,a=r(43210);let i={data:""},o=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||i,l=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,n=/\/\*[^]*?\*\/|  +/g,c=/\n+/g,d=(e,t)=>{let r="",s="",a="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?r=i+" "+o+";":s+="f"==i[1]?d(o,i):i+"{"+d(o,"k"==i[1]?"":t)+"}":"object"==typeof o?s+=d(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),a+=d.p?d.p(i,o):i+":"+o+";")}return r+(t&&a?t+"{"+a+"}":a)+s},u={},p=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+p(e[r]);return t}return e},m=(e,t,r,s,a)=>{let i=p(e),o=u[i]||(u[i]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(i));if(!u[o]){let t=i!==e?e:(e=>{let t,r,s=[{}];for(;t=l.exec(e.replace(n,""));)t[4]?s.shift():t[3]?(r=t[3].replace(c," ").trim(),s.unshift(s[0][r]=s[0][r]||{})):s[0][t[1]]=t[2].replace(c," ").trim();return s[0]})(e);u[o]=d(a?{["@keyframes "+o]:t}:t,r?"":"."+o)}let m=r&&u.g?u.g:null;return r&&(u.g=u[o]),((e,t,r,s)=>{s?t.data=t.data.replace(s,e):-1===t.data.indexOf(e)&&(t.data=r?e+t.data:t.data+e)})(u[o],t,s,m),o},x=(e,t,r)=>e.reduce((e,s,a)=>{let i=t[a];if(i&&i.call){let e=i(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+s+(null==i?"":i)},"");function h(e){let t=this||{},r=e.call?e(t.p):e;return m(r.unshift?r.raw?x(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,o(t.target),t.g,t.o,t.k)}h.bind({g:1});let f,g,b,y=h.bind({k:1});function v(e,t){let r=this||{};return function(){let s=arguments;function a(i,o){let l=Object.assign({},i),n=l.className||a.className;r.p=Object.assign({theme:g&&g()},l),r.o=/ *go\d+/.test(n),l.className=h.apply(r,s)+(n?" "+n:""),t&&(l.ref=o);let c=e;return e[0]&&(c=l.as||e,delete l.as),b&&c[0]&&b(l),f(c,l)}return t?t(a):a}}var N=e=>"function"==typeof e,j=(e,t)=>N(e)?e(t):e,w=(()=>{let e=0;return()=>(++e).toString()})(),k=(()=>{let e;return()=>e})(),P=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return P(e,{type:+!!e.toasts.find(e=>e.id===r.id),toast:r});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let a=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+a}))}}},C=[],A={toasts:[],pausedAt:void 0},E=e=>{A=P(A,e),C.forEach(e=>{e(A)})},q={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},$=(e={})=>{let[t,r]=(0,a.useState)(A),s=(0,a.useRef)(A);(0,a.useEffect)(()=>(s.current!==A&&r(A),C.push(r),()=>{let e=C.indexOf(r);e>-1&&C.splice(e,1)}),[]);let i=t.toasts.map(t=>{var r,s,a;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(s=e[t.type])?void 0:s.duration)||(null==e?void 0:e.duration)||q[t.type],style:{...e.style,...null==(a=e[t.type])?void 0:a.style,...t.style}}});return{...t,toasts:i}},F=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||w()}),_=e=>(t,r)=>{let s=F(t,e,r);return E({type:2,toast:s}),s.id},D=(e,t)=>_("blank")(e,t);D.error=_("error"),D.success=_("success"),D.loading=_("loading"),D.custom=_("custom"),D.dismiss=e=>{E({type:3,toastId:e})},D.remove=e=>E({type:4,toastId:e}),D.promise=(e,t,r)=>{let s=D.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let a=t.success?j(t.success,e):void 0;return a?D.success(a,{id:s,...r,...null==r?void 0:r.success}):D.dismiss(s),e}).catch(e=>{let a=t.error?j(t.error,e):void 0;a?D.error(a,{id:s,...r,...null==r?void 0:r.error}):D.dismiss(s)}),e};var I=(e,t)=>{E({type:1,toast:{id:e,height:t}})},O=()=>{E({type:5,time:Date.now()})},S=new Map,z=1e3,M=(e,t=z)=>{if(S.has(e))return;let r=setTimeout(()=>{S.delete(e),E({type:4,toastId:e})},t);S.set(e,r)},R=e=>{let{toasts:t,pausedAt:r}=$(e);(0,a.useEffect)(()=>{if(r)return;let e=Date.now(),s=t.map(t=>{if(t.duration===1/0)return;let r=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(r<0){t.visible&&D.dismiss(t.id);return}return setTimeout(()=>D.dismiss(t.id),r)});return()=>{s.forEach(e=>e&&clearTimeout(e))}},[t,r]);let s=(0,a.useCallback)(()=>{r&&E({type:6,time:Date.now()})},[r]),i=(0,a.useCallback)((e,r)=>{let{reverseOrder:s=!1,gutter:a=8,defaultPosition:i}=r||{},o=t.filter(t=>(t.position||i)===(e.position||i)&&t.height),l=o.findIndex(t=>t.id===e.id),n=o.filter((e,t)=>t<l&&e.visible).length;return o.filter(e=>e.visible).slice(...s?[n+1]:[0,n]).reduce((e,t)=>e+(t.height||0)+a,0)},[t]);return(0,a.useEffect)(()=>{t.forEach(e=>{if(e.dismissed)M(e.id,e.removeDelay);else{let t=S.get(e.id);t&&(clearTimeout(t),S.delete(e.id))}})},[t]),{toasts:t,handlers:{updateHeight:I,startPause:O,endPause:s,calculateOffset:i}}},T=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,U=y`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,G=y`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,L=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${T} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${U} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${G} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,H=y`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,B=v("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${H} 1s linear infinite;
`,Y=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,K=y`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Q=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Y} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${K} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,W=v("div")`
  position: absolute;
`,X=v("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,Z=y`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,J=v("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${Z} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,V=({toast:e})=>{let{icon:t,type:r,iconTheme:s}=e;return void 0!==t?"string"==typeof t?a.createElement(J,null,t):t:"blank"===r?null:a.createElement(X,null,a.createElement(B,{...s}),"loading"!==r&&a.createElement(W,null,"error"===r?a.createElement(L,{...s}):a.createElement(Q,{...s})))},ee=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,et=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,er=v("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,es=v("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ea=(e,t)=>{let r=e.includes("top")?1:-1,[s,a]=k()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ee(r),et(r)];return{animation:t?`${y(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${y(a)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},ei=a.memo(({toast:e,position:t,style:r,children:s})=>{let i=e.height?ea(e.position||t||"top-center",e.visible):{opacity:0},o=a.createElement(V,{toast:e}),l=a.createElement(es,{...e.ariaProps},j(e.message,e));return a.createElement(er,{className:e.className,style:{...i,...r,...e.style}},"function"==typeof s?s({icon:o,message:l}):a.createElement(a.Fragment,null,o,l))});s=a.createElement,d.p=void 0,f=s,g=void 0,b=void 0;var eo=({id:e,className:t,style:r,onHeightUpdate:s,children:i})=>{let o=a.useCallback(t=>{if(t){let r=()=>{s(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,s]);return a.createElement("div",{ref:o,className:t,style:r},i)},el=(e,t)=>{let r=e.includes("top"),s=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:k()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...r?{top:0}:{bottom:0},...s}},en=h`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ec=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:s,children:i,containerStyle:o,containerClassName:l})=>{let{toasts:n,handlers:c}=R(r);return a.createElement("div",{id:"_rht_toaster",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...o},className:l,onMouseEnter:c.startPause,onMouseLeave:c.endPause},n.map(r=>{let o=r.position||t,l=el(o,c.calculateOffset(r,{reverseOrder:e,gutter:s,defaultPosition:t}));return a.createElement(eo,{id:r.id,key:r.id,onHeightUpdate:c.updateHeight,className:r.visible?en:"",style:l},"custom"===r.type?j(r.message,r):i?i(r):a.createElement(ei,{toast:r,position:o}))}))},ed=D},37989:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>s});let s=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\Pelumi Isola\\\\Desktop\\\\high-taste-ceramics\\\\src\\\\app\\\\checkout\\\\page.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\checkout\\page.jsx","default")},43050:(e,t,r)=>{Promise.resolve().then(r.bind(r,37989))},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},90836:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>o.a,__next_app__:()=>u,pages:()=>d,routeModule:()=>p,tree:()=>c});var s=r(65239),a=r(48088),i=r(88170),o=r.n(i),l=r(30893),n={};for(let e in l)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>l[e]);r.d(t,n);let c={children:["",{children:["checkout",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,37989)),"C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\checkout\\page.jsx"]}]},{metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(r.bind(r,75535)),"C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\layout.js"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,57398,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,d=["C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\checkout\\page.jsx"],u={require:r,loadChunk:()=>Promise.resolve()},p=new s.AppPageRouteModule({definition:{kind:a.RouteKind.APP_PAGE,page:"/checkout/page",pathname:"/checkout",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},91368:(e,t,r)=>{"use strict";r.d(t,{A:()=>o});var s=r(60687);r(43210);var a=r(16189),i=r(72106);function o(e,{requireAuth:t=!1,redirectTo:r="/sign-in"}={}){return function(r){(0,a.useRouter)();let o=(0,i.A)(e=>e.user);return t&&!o||!t&&o?null:(0,s.jsx)(e,{...r})}}},94735:e=>{"use strict";e.exports=require("events")}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[447,825,224,151,60,643],()=>r(90836));module.exports=s})();