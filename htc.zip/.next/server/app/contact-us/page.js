(()=>{var e={};e.id=920,e.ids=[920],e.modules={2822:()=>{},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10136:()=>{},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12412:e=>{"use strict";e.exports=require("assert")},14606:(e,t,s)=>{"use strict";s.d(t,{Kl:()=>a,Pt:()=>n,cw:()=>i,jy:()=>o,qR:()=>l});var r=s(16261);let a=async e=>(await r.A.get("/product/categories")).data,i=async()=>(await r.A.get("/product/featured")).data,o=async e=>(await r.A.get(`/product/category/${e}`)).data,l=async e=>(await r.A.get(`/product/${e}`)).data,n=async(e,t)=>(console.log("Checkout data:",e),(await r.A.post("/cart/checkout",{...e},{headers:{Authorization:`Bearer ${t}`}})).data)},16261:(e,t,s)=>{"use strict";s.d(t,{A:()=>a});let r=s(51060).A.create({baseURL:"https://api.hightasteceramics.com/api",withCredentials:!1});r.interceptors.response.use(e=>e,e=>(e.response&&e.response.status,Promise.reject(e)));let a=r},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21820:e=>{"use strict";e.exports=require("os")},22971:(e,t,s)=>{"use strict";s.d(t,{A:()=>p});var r=s(60687),a=s(30474),i=s(85814),o=s.n(i),l=s(43210),n=s(32036),c=s(6042);s(72106);var d=s(14606);let p=()=>{let[e,t]=(0,l.useState)([]);return(0,l.useEffect)(()=>{(async()=>{try{let e=await (0,d.cw)();console.log("Featured Products:",e.payload),t(e.payload)}catch(e){console.error("Error fetching featured products:",e)}})()},[]),(0,r.jsxs)("section",{className:"w-full bg-[#EFEBE2] md:px-10 px-4 py-20",children:[(0,r.jsxs)("div",{className:"flex items-center justify-between",children:[(0,r.jsx)("h1",{className:"font-[Publicko] font-[300] text-[#242222] text-5xl",children:"Featured Products"}),(0,r.jsx)(o(),{href:"/contact-us",className:"px-5 py-2 text-[#242222] border border-[#242222] font-semibold text-sm rounded-full  hover:bg-[#242222] hover:text-white  transition-colors duration-300 ease-in-out",children:"Learn more"})]}),(0,r.jsx)(n.RC,{spaceBetween:10,slidesPerView:1,breakpoints:{640:{slidesPerView:1},768:{slidesPerView:2},1024:{slidesPerView:3},1440:{slidesPerView:4}},scrollbar:{draggable:!0},modules:[c.Ze],className:"mt-20 !pb-20",children:e&&e.length>0?e.map((e,t)=>(0,r.jsx)(n.qr,{children:(0,r.jsxs)(o(),{href:`/products/details/${e?.id}`,className:"overflow-hidden group relative cursor-pointer",children:[(0,r.jsx)("div",{className:"relative h-100 overflow-hidden",children:(0,r.jsx)(a.default,{src:e?.image,alt:e?.name,fill:!0,className:"object-cover transition-transform duration-500 group-hover:scale-105"})}),(0,r.jsx)("div",{className:"flex items-center justify-between",children:(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-left text-sm text-[#242222]",children:e?.category?.name}),(0,r.jsx)("p",{className:"text-left text-sm text-[#242222] font-[Publicko]",children:e?.name})]})})]})},t)):Array.from({length:4}).map((e,t)=>(0,r.jsx)(n.qr,{children:(0,r.jsxs)("div",{className:"overflow-hidden group relative cursor-pointer animate-pulse",children:[(0,r.jsx)("div",{className:"relative h-100 overflow-hidden bg-gray-200 rounded-md min-h-[220px] flex items-center justify-center",children:(0,r.jsx)("div",{className:"absolute inset-0 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-skeleton"})}),(0,r.jsxs)("div",{className:"flex flex-col w-[90%] absolute bottom-5 py-2 items-center justify-center bg-white/80",children:[(0,r.jsx)("div",{className:"h-4 bg-gray-200 rounded w-3/4 mb-2"}),(0,r.jsx)("div",{className:"h-3 bg-gray-200 rounded w-1/2"})]})]})},"skeleton-"+t))})]})}},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},31588:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>o.a,__next_app__:()=>p,pages:()=>d,routeModule:()=>u,tree:()=>c});var r=s(65239),a=s(48088),i=s(88170),o=s.n(i),l=s(30893),n={};for(let e in l)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>l[e]);s.d(t,n);let c={children:["",{children:["contact-us",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,92346)),"C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\contact-us\\page.jsx"]}]},{metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(s.bind(s,75535)),"C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\layout.js"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,57398,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(s.t.bind(s,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(s.t.bind(s,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,d=["C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\contact-us\\page.jsx"],p={require:s,loadChunk:()=>Promise.resolve()},u=new r.AppPageRouteModule({definition:{kind:a.RouteKind.APP_PAGE,page:"/contact-us/page",pathname:"/contact-us",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},32379:(e,t,s)=>{Promise.resolve().then(s.bind(s,50674))},33873:e=>{"use strict";e.exports=require("path")},37590:(e,t,s)=>{"use strict";s.d(t,{l$:()=>ec,Ay:()=>ed,oR:()=>F});var r,a=s(43210);let i={data:""},o=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||i,l=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,n=/\/\*[^]*?\*\/|  +/g,c=/\n+/g,d=(e,t)=>{let s="",r="",a="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?s=i+" "+o+";":r+="f"==i[1]?d(o,i):i+"{"+d(o,"k"==i[1]?"":t)+"}":"object"==typeof o?r+=d(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),a+=d.p?d.p(i,o):i+":"+o+";")}return s+(t&&a?t+"{"+a+"}":a)+r},p={},u=e=>{if("object"==typeof e){let t="";for(let s in e)t+=s+u(e[s]);return t}return e},m=(e,t,s,r,a)=>{let i=u(e),o=p[i]||(p[i]=(e=>{let t=0,s=11;for(;t<e.length;)s=101*s+e.charCodeAt(t++)>>>0;return"go"+s})(i));if(!p[o]){let t=i!==e?e:(e=>{let t,s,r=[{}];for(;t=l.exec(e.replace(n,""));)t[4]?r.shift():t[3]?(s=t[3].replace(c," ").trim(),r.unshift(r[0][s]=r[0][s]||{})):r[0][t[1]]=t[2].replace(c," ").trim();return r[0]})(e);p[o]=d(a?{["@keyframes "+o]:t}:t,s?"":"."+o)}let m=s&&p.g?p.g:null;return s&&(p.g=p[o]),((e,t,s,r)=>{r?t.data=t.data.replace(r,e):-1===t.data.indexOf(e)&&(t.data=s?e+t.data:t.data+e)})(p[o],t,r,m),o},f=(e,t,s)=>e.reduce((e,r,a)=>{let i=t[a];if(i&&i.call){let e=i(s),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"");function x(e){let t=this||{},s=e.call?e(t.p):e;return m(s.unshift?s.raw?f(s,[].slice.call(arguments,1),t.p):s.reduce((e,s)=>Object.assign(e,s&&s.call?s(t.p):s),{}):s,o(t.target),t.g,t.o,t.k)}x.bind({g:1});let h,g,b,y=x.bind({k:1});function v(e,t){let s=this||{};return function(){let r=arguments;function a(i,o){let l=Object.assign({},i),n=l.className||a.className;s.p=Object.assign({theme:g&&g()},l),s.o=/ *go\d+/.test(n),l.className=x.apply(s,r)+(n?" "+n:""),t&&(l.ref=o);let c=e;return e[0]&&(c=l.as||e,delete l.as),b&&c[0]&&b(l),h(c,l)}return t?t(a):a}}var w=e=>"function"==typeof e,j=(e,t)=>w(e)?e(t):e,N=(()=>{let e=0;return()=>(++e).toString()})(),P=(()=>{let e;return()=>e})(),k=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:s}=t;return k(e,{type:+!!e.toasts.find(e=>e.id===s.id),toast:s});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let a=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+a}))}}},E=[],A={toasts:[],pausedAt:void 0},C=e=>{A=k(A,e),E.forEach(e=>{e(A)})},q={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},$=(e={})=>{let[t,s]=(0,a.useState)(A),r=(0,a.useRef)(A);(0,a.useEffect)(()=>(r.current!==A&&s(A),E.push(s),()=>{let e=E.indexOf(s);e>-1&&E.splice(e,1)}),[]);let i=t.toasts.map(t=>{var s,r,a;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(s=e[t.type])?void 0:s.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(r=e[t.type])?void 0:r.duration)||(null==e?void 0:e.duration)||q[t.type],style:{...e.style,...null==(a=e[t.type])?void 0:a.style,...t.style}}});return{...t,toasts:i}},_=(e,t="blank",s)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...s,id:(null==s?void 0:s.id)||N()}),D=e=>(t,s)=>{let r=_(t,e,s);return C({type:2,toast:r}),r.id},F=(e,t)=>D("blank")(e,t);F.error=D("error"),F.success=D("success"),F.loading=D("loading"),F.custom=D("custom"),F.dismiss=e=>{C({type:3,toastId:e})},F.remove=e=>C({type:4,toastId:e}),F.promise=(e,t,s)=>{let r=F.loading(t.loading,{...s,...null==s?void 0:s.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let a=t.success?j(t.success,e):void 0;return a?F.success(a,{id:r,...s,...null==s?void 0:s.success}):F.dismiss(r),e}).catch(e=>{let a=t.error?j(t.error,e):void 0;a?F.error(a,{id:r,...s,...null==s?void 0:s.error}):F.dismiss(r)}),e};var z=(e,t)=>{C({type:1,toast:{id:e,height:t}})},O=()=>{C({type:5,time:Date.now()})},I=new Map,M=1e3,S=(e,t=M)=>{if(I.has(e))return;let s=setTimeout(()=>{I.delete(e),C({type:4,toastId:e})},t);I.set(e,s)},R=e=>{let{toasts:t,pausedAt:s}=$(e);(0,a.useEffect)(()=>{if(s)return;let e=Date.now(),r=t.map(t=>{if(t.duration===1/0)return;let s=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(s<0){t.visible&&F.dismiss(t.id);return}return setTimeout(()=>F.dismiss(t.id),s)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[t,s]);let r=(0,a.useCallback)(()=>{s&&C({type:6,time:Date.now()})},[s]),i=(0,a.useCallback)((e,s)=>{let{reverseOrder:r=!1,gutter:a=8,defaultPosition:i}=s||{},o=t.filter(t=>(t.position||i)===(e.position||i)&&t.height),l=o.findIndex(t=>t.id===e.id),n=o.filter((e,t)=>t<l&&e.visible).length;return o.filter(e=>e.visible).slice(...r?[n+1]:[0,n]).reduce((e,t)=>e+(t.height||0)+a,0)},[t]);return(0,a.useEffect)(()=>{t.forEach(e=>{if(e.dismissed)S(e.id,e.removeDelay);else{let t=I.get(e.id);t&&(clearTimeout(t),I.delete(e.id))}})},[t]),{toasts:t,handlers:{updateHeight:z,startPause:O,endPause:r,calculateOffset:i}}},T=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,G=y`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,U=y`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,B=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${T} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${G} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${U} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,H=y`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,L=v("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${H} 1s linear infinite;
`,V=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,K=y`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Y=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${V} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${K} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,Z=v("div")`
  position: absolute;
`,W=v("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,X=y`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,J=v("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${X} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Q=({toast:e})=>{let{icon:t,type:s,iconTheme:r}=e;return void 0!==t?"string"==typeof t?a.createElement(J,null,t):t:"blank"===s?null:a.createElement(W,null,a.createElement(L,{...r}),"loading"!==s&&a.createElement(Z,null,"error"===s?a.createElement(B,{...r}):a.createElement(Y,{...r})))},ee=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,et=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,es=v("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,er=v("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ea=(e,t)=>{let s=e.includes("top")?1:-1,[r,a]=P()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ee(s),et(s)];return{animation:t?`${y(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${y(a)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},ei=a.memo(({toast:e,position:t,style:s,children:r})=>{let i=e.height?ea(e.position||t||"top-center",e.visible):{opacity:0},o=a.createElement(Q,{toast:e}),l=a.createElement(er,{...e.ariaProps},j(e.message,e));return a.createElement(es,{className:e.className,style:{...i,...s,...e.style}},"function"==typeof r?r({icon:o,message:l}):a.createElement(a.Fragment,null,o,l))});r=a.createElement,d.p=void 0,h=r,g=void 0,b=void 0;var eo=({id:e,className:t,style:s,onHeightUpdate:r,children:i})=>{let o=a.useCallback(t=>{if(t){let s=()=>{r(e,t.getBoundingClientRect().height)};s(),new MutationObserver(s).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return a.createElement("div",{ref:o,className:t,style:s},i)},el=(e,t)=>{let s=e.includes("top"),r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:P()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(s?1:-1)}px)`,...s?{top:0}:{bottom:0},...r}},en=x`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ec=({reverseOrder:e,position:t="top-center",toastOptions:s,gutter:r,children:i,containerStyle:o,containerClassName:l})=>{let{toasts:n,handlers:c}=R(s);return a.createElement("div",{id:"_rht_toaster",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...o},className:l,onMouseEnter:c.startPause,onMouseLeave:c.endPause},n.map(s=>{let o=s.position||t,l=el(o,c.calculateOffset(s,{reverseOrder:e,gutter:r,defaultPosition:t}));return a.createElement(eo,{id:s.id,key:s.id,onHeightUpdate:c.updateHeight,className:s.visible?en:"",style:l},"custom"===s.type?j(s.message,s):i?i(s):a.createElement(ei,{toast:s,position:o}))}))},ed=F},50674:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>u});var r=s(60687);s(30474);var a=s(85814),i=s.n(a),o=s(43210);s(32036),s(2822),s(10136),s(6042);var l=s(39952),n=s(22971),c=s(37590),d=s(16261);let p=async e=>(await d.A.post("/contact",{...e})).data,u=()=>{let[e,t]=(0,o.useState)({name:"",email:"",message:""}),[s,a]=(0,o.useState)(!1),d=s=>{t({...e,[s.target.id]:s.target.value})},u=async s=>{if(s.preventDefault(),!e.name.trim()||!e.email.trim()||!e.message.trim())return void c.Ay.error("Please fill in all fields.");if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.email))return void c.Ay.error("Please enter a valid email address.");a(!0);try{await p(e),c.Ay.success("Message sent successfully!"),t({name:"",email:"",message:""})}catch(e){console.error("Error sending message:",e),c.Ay.error("Failed to send message. Please try again.")}finally{a(!1)}};return(0,r.jsxs)(l.A,{children:[(0,r.jsx)("section",{className:"w-full py-40 pt-60 flex flex-col items-center justify-center bg-[#EFEBE2] md:px-10 px-5",children:(0,r.jsx)("div",{className:"w-full flex flex-col gap-8 items-center border-b border-[rgba(36,34,34,0.15)] pb-10 mb-14",children:(0,r.jsx)("h1",{"data-aos":"fade-up","data-aos-offset":"200","data-aos-duration":"500","data-aos-easing":"ease-in-out","data-aos-mirror":"true","data-aos-once":"true","data-aos-anchor-placement":"top-center",className:"md:text-[140px] text-4xl !font-[300] text-[#242222] font-[Publicko] text-center leading-18 ",children:"Get in Touch"})})}),(0,r.jsxs)("section",{className:"w-full flex flex-col md:flex-row bg-[#EFEFEF] md:px-10 px-4 py-20 gap-10",children:[(0,r.jsxs)("div",{className:"w-full md:w-1/2 space-y-6",children:[(0,r.jsx)("h1",{className:"font-[Publicko] font-[300] text-[#242222] text-3xl",children:"Get in Touch"}),(0,r.jsx)("p",{className:"text-lg text-[#242222]",children:"Have questions? Our team is ready to help."}),(0,r.jsxs)("div",{className:"flex items-center gap-4 text-[#242222]",children:[(0,r.jsx)("div",{className:"bg-[#f8f8f8] p-3 rounded-full flex items-center justify-center w-10 h-10",children:(0,r.jsx)("i",{className:"ri-map-pin-line text-lg text-[#242222]"})}),(0,r.jsx)("p",{children:"2 Opeyemi Bamidele Street, Lekki Phase 1"})]}),(0,r.jsxs)("div",{className:"flex items-center gap-4 text-[#242222]",children:[(0,r.jsx)("div",{className:"bg-[#f8f8f8] p-3 rounded-full flex items-center justify-center w-10 h-10",children:(0,r.jsx)("i",{className:"ri-phone-line text-lg text-[#242222]"})}),(0,r.jsx)(i(),{href:"tel:+234816345399",children:"+234 816 345 3995"})]}),(0,r.jsxs)("div",{className:"flex items-center gap-4 text-[#242222]",children:[(0,r.jsx)("div",{className:"bg-[#f8f8f8] p-3 rounded-full flex items-center justify-center w-10 h-10",children:(0,r.jsx)("i",{className:"ri-mail-line text-lg text-[#242222]"})}),(0,r.jsx)("p",{children:"info@hightasteceramics.com"})]}),(0,r.jsxs)("div",{className:"flex items-center gap-4 text-[#242222]",children:[(0,r.jsx)("div",{className:"bg-[#f8f8f8] p-3 rounded-full flex items-center justify-center w-10 h-10",children:(0,r.jsx)("i",{className:"ri-whatsapp-line text-lg text-[#242222]"})}),(0,r.jsx)("a",{href:"https://wa.me/2349090222221",target:"_blank",rel:"noopener noreferrer",className:"hover:underline",children:"+234 909 022 2221"})]}),(0,r.jsxs)("div",{className:"flex items-center gap-4 text-[#242222]",children:[(0,r.jsx)("div",{className:"bg-[#f8f8f8] p-3 rounded-full flex items-center justify-center w-10 h-10",children:(0,r.jsx)("i",{className:"ri-instagram-line text-lg text-[#242222]"})}),(0,r.jsx)("a",{href:"https://instagram.com/high.taste.ceramics",target:"_blank",rel:"noopener noreferrer",className:"hover:underline",children:"@high.taste.ceramics"})]})]}),(0,r.jsx)("div",{className:"w-full md:w-1/2 bg-[#F8F8F8] p-8 md:p-12 ",children:(0,r.jsxs)("form",{className:"flex flex-col gap-8",onSubmit:u,children:[(0,r.jsx)("h2",{className:"text-2xl md:text-3xl font-[Publicko] text-[#242222] mb-4",children:"Send us a message"}),(0,r.jsxs)("div",{className:"relative",children:[(0,r.jsx)("input",{type:"text",id:"name",required:!0,value:e.name,onChange:d,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Name"}),(0,r.jsx)("label",{htmlFor:"name",className:"absolute left-4 top-2 text-sm text-[#777] transition-all peer-placeholder-shown:top-4 peer-placeholder-shown:text-base peer-placeholder-shown:text-[#aaa] peer-focus:top-2 peer-focus:text-sm peer-focus:text-[#242222]",children:"Name"})]}),(0,r.jsxs)("div",{className:"relative",children:[(0,r.jsx)("input",{type:"email",id:"email",required:!0,value:e.email,onChange:d,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222]",placeholder:"Email"}),(0,r.jsx)("label",{htmlFor:"email",className:"absolute left-4 top-2 text-sm text-[#777] transition-all peer-placeholder-shown:top-4 peer-placeholder-shown:text-base peer-placeholder-shown:text-[#aaa] peer-focus:top-2 peer-focus:text-sm peer-focus:text-[#242222]",children:"Email"})]}),(0,r.jsxs)("div",{className:"relative",children:[(0,r.jsx)("textarea",{id:"message",rows:5,required:!0,value:e.message,onChange:d,className:"w-full px-4 pt-5 pb-2 rounded-lg border border-[#ccc] bg-white text-[#242222] placeholder-transparent focus:outline-none focus:ring-1 focus:ring-[#242222] resize-none",placeholder:"Your Message"}),(0,r.jsx)("label",{htmlFor:"message",className:"absolute left-4 top-2 text-sm text-[#777] transition-all peer-placeholder-shown:top-4 peer-placeholder-shown:text-base peer-placeholder-shown:text-[#aaa] peer-focus:top-2 peer-focus:text-sm peer-focus:text-[#242222]",children:"Message"})]}),(0,r.jsxs)("button",{type:"submit",className:"bg-[#242222] text-white py-3 px-6 rounded-xl hover:bg-[#3a3838] transition-all duration-200 text-base font-medium shadow-md flex items-center justify-center gap-2",disabled:s,children:[s&&(0,r.jsxs)("svg",{className:"animate-spin h-5 w-5 text-white",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",children:[(0,r.jsx)("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4"}),(0,r.jsx)("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"})]}),s?"Sending...":"Send Message"]})]})})]}),(0,r.jsx)(c.l$,{}),(0,r.jsx)(n.A,{})]})}},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66723:(e,t,s)=>{Promise.resolve().then(s.bind(s,92346))},74075:e=>{"use strict";e.exports=require("zlib")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},92346:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>r});let r=(0,s(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\Pelumi Isola\\\\Desktop\\\\high-taste-ceramics\\\\src\\\\app\\\\contact-us\\\\page.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\Pelumi Isola\\Desktop\\high-taste-ceramics\\src\\app\\contact-us\\page.jsx","default")},94735:e=>{"use strict";e.exports=require("events")}};var t=require("../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[447,825,224,151,60,343,643],()=>s(31588));module.exports=r})();