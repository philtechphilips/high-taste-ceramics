exports.id=910,exports.ids=[910],exports.modules={2822:()=>{},10136:()=>{},14606:(e,t,a)=>{"use strict";a.d(t,{Kl:()=>s,Pt:()=>l,cw:()=>o,jy:()=>i,qR:()=>n});var r=a(16261);let s=async e=>(await r.A.get("/product/categories")).data,o=async()=>(await r.A.get("/product/featured")).data,i=async e=>(await r.A.get(`/product/category/${e}`)).data,n=async e=>(await r.A.get(`/product/${e}`)).data,l=async(e,t)=>(console.log("Checkout data:",e),(await r.A.post("/cart/checkout",{...e},{headers:{Authorization:`Bearer ${t}`}})).data)},16261:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let r=a(51060).A.create({baseURL:"https://api.hightasteceramics.com/api",withCredentials:!1});r.interceptors.response.use(e=>e,e=>(e.response&&e.response.status,Promise.reject(e)));let s=r},37590:(e,t,a)=>{"use strict";a.d(t,{l$:()=>ed,Ay:()=>ec,oR:()=>I});var r,s=a(43210);let o={data:""},i=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||o,n=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,l=/\/\*[^]*?\*\/|  +/g,d=/\n+/g,c=(e,t)=>{let a="",r="",s="";for(let o in e){let i=e[o];"@"==o[0]?"i"==o[1]?a=o+" "+i+";":r+="f"==o[1]?c(i,o):o+"{"+c(i,"k"==o[1]?"":t)+"}":"object"==typeof i?r+=c(i,t?t.replace(/([^,])+/g,e=>o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):o):null!=i&&(o=/^--/.test(o)?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=c.p?c.p(o,i):o+":"+i+";")}return a+(t&&s?t+"{"+s+"}":s)+r},p={},u=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+u(e[a]);return t}return e},m=(e,t,a,r,s)=>{let o=u(e),i=p[o]||(p[o]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(o));if(!p[i]){let t=o!==e?e:(e=>{let t,a,r=[{}];for(;t=n.exec(e.replace(l,""));)t[4]?r.shift():t[3]?(a=t[3].replace(d," ").trim(),r.unshift(r[0][a]=r[0][a]||{})):r[0][t[1]]=t[2].replace(d," ").trim();return r[0]})(e);p[i]=c(s?{["@keyframes "+i]:t}:t,a?"":"."+i)}let m=a&&p.g?p.g:null;return a&&(p.g=p[i]),((e,t,a,r)=>{r?t.data=t.data.replace(r,e):-1===t.data.indexOf(e)&&(t.data=a?e+t.data:t.data+e)})(p[i],t,r,m),i},f=(e,t,a)=>e.reduce((e,r,s)=>{let o=t[s];if(o&&o.call){let e=o(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;o=t?"."+t:e&&"object"==typeof e?e.props?"":c(e,""):!1===e?"":e}return e+r+(null==o?"":o)},"");function g(e){let t=this||{},a=e.call?e(t.p):e;return m(a.unshift?a.raw?f(a,[].slice.call(arguments,1),t.p):a.reduce((e,a)=>Object.assign(e,a&&a.call?a(t.p):a),{}):a,i(t.target),t.g,t.o,t.k)}g.bind({g:1});let y,h,x,b=g.bind({k:1});function v(e,t){let a=this||{};return function(){let r=arguments;function s(o,i){let n=Object.assign({},o),l=n.className||s.className;a.p=Object.assign({theme:h&&h()},n),a.o=/ *go\d+/.test(l),n.className=g.apply(a,r)+(l?" "+l:""),t&&(n.ref=i);let d=e;return e[0]&&(d=n.as||e,delete n.as),x&&d[0]&&x(n),y(d,n)}return t?t(s):s}}var w=e=>"function"==typeof e,j=(e,t)=>w(e)?e(t):e,N=(()=>{let e=0;return()=>(++e).toString()})(),E=(()=>{let e;return()=>e})(),$=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return $(e,{type:+!!e.toasts.find(e=>e.id===a.id),toast:a});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let s=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+s}))}}},A=[],k={toasts:[],pausedAt:void 0},C=e=>{k=$(k,e),A.forEach(e=>{e(k)})},D={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},O=(e={})=>{let[t,a]=(0,s.useState)(k),r=(0,s.useRef)(k);(0,s.useEffect)(()=>(r.current!==k&&a(k),A.push(a),()=>{let e=A.indexOf(a);e>-1&&A.splice(e,1)}),[]);let o=t.toasts.map(t=>{var a,r,s;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(a=e[t.type])?void 0:a.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(r=e[t.type])?void 0:r.duration)||(null==e?void 0:e.duration)||D[t.type],style:{...e.style,...null==(s=e[t.type])?void 0:s.style,...t.style}}});return{...t,toasts:o}},z=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||N()}),P=e=>(t,a)=>{let r=z(t,e,a);return C({type:2,toast:r}),r.id},I=(e,t)=>P("blank")(e,t);I.error=P("error"),I.success=P("success"),I.loading=P("loading"),I.custom=P("custom"),I.dismiss=e=>{C({type:3,toastId:e})},I.remove=e=>C({type:4,toastId:e}),I.promise=(e,t,a)=>{let r=I.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?j(t.success,e):void 0;return s?I.success(s,{id:r,...a,...null==a?void 0:a.success}):I.dismiss(r),e}).catch(e=>{let s=t.error?j(t.error,e):void 0;s?I.error(s,{id:r,...a,...null==a?void 0:a.error}):I.dismiss(r)}),e};var F=(e,t)=>{C({type:1,toast:{id:e,height:t}})},S=()=>{C({type:5,time:Date.now()})},T=new Map,_=1e3,H=(e,t=_)=>{if(T.has(e))return;let a=setTimeout(()=>{T.delete(e),C({type:4,toastId:e})},t);T.set(e,a)},L=e=>{let{toasts:t,pausedAt:a}=O(e);(0,s.useEffect)(()=>{if(a)return;let e=Date.now(),r=t.map(t=>{if(t.duration===1/0)return;let a=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(a<0){t.visible&&I.dismiss(t.id);return}return setTimeout(()=>I.dismiss(t.id),a)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[t,a]);let r=(0,s.useCallback)(()=>{a&&C({type:6,time:Date.now()})},[a]),o=(0,s.useCallback)((e,a)=>{let{reverseOrder:r=!1,gutter:s=8,defaultPosition:o}=a||{},i=t.filter(t=>(t.position||o)===(e.position||o)&&t.height),n=i.findIndex(t=>t.id===e.id),l=i.filter((e,t)=>t<n&&e.visible).length;return i.filter(e=>e.visible).slice(...r?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+s,0)},[t]);return(0,s.useEffect)(()=>{t.forEach(e=>{if(e.dismissed)H(e.id,e.removeDelay);else{let t=T.get(e.id);t&&(clearTimeout(t),T.delete(e.id))}})},[t]),{toasts:t,handlers:{updateHeight:F,startPause:S,endPause:r,calculateOffset:o}}},M=b`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,R=b`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,U=b`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,q=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${M} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${R} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${U} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,B=b`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,K=v("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${B} 1s linear infinite;
`,Y=b`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,Z=b`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,G=v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Y} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${Z} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,J=v("div")`
  position: absolute;
`,Q=v("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,V=b`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,W=v("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${V} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,X=({toast:e})=>{let{icon:t,type:a,iconTheme:r}=e;return void 0!==t?"string"==typeof t?s.createElement(W,null,t):t:"blank"===a?null:s.createElement(Q,null,s.createElement(K,{...r}),"loading"!==a&&s.createElement(J,null,"error"===a?s.createElement(q,{...r}):s.createElement(G,{...r})))},ee=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,et=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,ea=v("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,er=v("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,es=(e,t)=>{let a=e.includes("top")?1:-1,[r,s]=E()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ee(a),et(a)];return{animation:t?`${b(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${b(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},eo=s.memo(({toast:e,position:t,style:a,children:r})=>{let o=e.height?es(e.position||t||"top-center",e.visible):{opacity:0},i=s.createElement(X,{toast:e}),n=s.createElement(er,{...e.ariaProps},j(e.message,e));return s.createElement(ea,{className:e.className,style:{...o,...a,...e.style}},"function"==typeof r?r({icon:i,message:n}):s.createElement(s.Fragment,null,i,n))});r=s.createElement,c.p=void 0,y=r,h=void 0,x=void 0;var ei=({id:e,className:t,style:a,onHeightUpdate:r,children:o})=>{let i=s.useCallback(t=>{if(t){let a=()=>{r(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return s.createElement("div",{ref:i,className:t,style:a},o)},en=(e,t)=>{let a=e.includes("top"),r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:E()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...a?{top:0}:{bottom:0},...r}},el=g`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ed=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:r,children:o,containerStyle:i,containerClassName:n})=>{let{toasts:l,handlers:d}=L(a);return s.createElement("div",{id:"_rht_toaster",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...i},className:n,onMouseEnter:d.startPause,onMouseLeave:d.endPause},l.map(a=>{let i=a.position||t,n=en(i,d.calculateOffset(a,{reverseOrder:e,gutter:r,defaultPosition:t}));return s.createElement(ei,{id:a.id,key:a.id,onHeightUpdate:d.updateHeight,className:a.visible?el:"",style:n},"custom"===a.type?j(a.message,a):o?o(a):s.createElement(eo,{toast:a,position:i}))}))},ec=I},40242:(e,t,a)=>{"use strict";a.d(t,{A:()=>p});var r=a(60687),s=a(30474),o=a(43210),i=a(14606),n=a(72106),l=a(37590),d=a(85814),c=a.n(d);let p=()=>{let[e,t]=(0,o.useState)([]),[a,d]=(0,o.useState)(!1);return(0,n.A)(e=>e.user),(0,o.useEffect)(()=>{(async()=>{d(!0);try{let e=await (0,i.Kl)();console.log("Fetched categories:",e),t(e?.payload)}catch(e){t([]),l.Ay.error(e?.message||"Failed to fetch categories")}finally{d(!1)}})()},[]),(0,r.jsxs)("section",{className:"w-full bg-white md:px-10 px-4 py-20",children:[(0,r.jsx)("h1",{className:"font-[Publicko] font-[300] text-[#242222] text-5xl",children:"Our Collections"}),(0,r.jsx)("div",{className:"w-full grid md:grid-cols-3 grid-cols-1 gap-x-6 md:gap-y-12 gap-y-12 mt-10",children:a?Array.from({length:6}).map((e,t)=>(0,r.jsxs)("div",{className:"overflow-hidden group relative cursor-pointer animate-pulse",children:[(0,r.jsx)("div",{className:"relative h-100 overflow-hidden px-10 flex items-center justify-center bg-gray-200 rounded-md min-h-[220px]",children:(0,r.jsx)("div",{className:"absolute inset-0 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-skeleton"})}),(0,r.jsxs)("div",{className:"flex flex-col w-[90%] absolute bottom-5 py-2 items-center justify-center bg-white/80",children:[(0,r.jsx)("div",{className:"h-4 bg-gray-200 rounded w-3/4 mb-2"}),(0,r.jsx)("div",{className:"h-3 bg-gray-200 rounded w-1/2"})]})]},t)):e.length>0?e.map((e,t)=>(0,r.jsx)(c(),{href:`/products/${e?.id}`,className:"overflow-hidden group relative cursor-pointer",children:(0,r.jsxs)("div",{className:"relative h-100 overflow-hidden px-10 flex items-center justify-center",children:[(0,r.jsx)(s.default,{src:e?.image||"/tiles.png",alt:e?.name||"Category",fill:!0,className:"object-cover transition-transform duration-500 group-hover:scale-105","data-aos":"fade-up","data-aos-offset":"200","data-aos-duration":"500","data-aos-easing":"ease-in-out","data-aos-mirror":"true","data-aos-once":"true","data-aos-anchor-placement":"top-center"}),(0,r.jsxs)("div",{className:"flex flex-col w-[90%] absolute bottom-5 py-2 items-center justify-center bg-white/80",children:[(0,r.jsx)("p",{className:"relative text-center font-semibold text-[#242222]",children:e?.name}),(0,r.jsxs)("p",{className:"relative text-center text-sm font-semibold text-[#424242]",children:[e?.productCount," product(s)"]})]})]})},e._id||t)):(0,r.jsx)("p",{className:"col-span-3 text-center text-gray-500",children:"No categories found."})})]})}}};